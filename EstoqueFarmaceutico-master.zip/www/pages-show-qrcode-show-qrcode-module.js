(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-show-qrcode-show-qrcode-module"],{

/***/ "./src/app/pages/show-qrcode/show-qrcode.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/show-qrcode/show-qrcode.module.ts ***!
  \*********************************************************/
/*! exports provided: ShowQrcodePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShowQrcodePageModule", function() { return ShowQrcodePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _show_qrcode_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./show-qrcode.page */ "./src/app/pages/show-qrcode/show-qrcode.page.ts");
/* harmony import */ var ngx_qrcode2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-qrcode2 */ "./node_modules/ngx-qrcode2/index.js");








var routes = [
    {
        path: '',
        component: _show_qrcode_page__WEBPACK_IMPORTED_MODULE_6__["ShowQrcodePage"]
    }
];
var ShowQrcodePageModule = /** @class */ (function () {
    function ShowQrcodePageModule() {
    }
    ShowQrcodePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
                ngx_qrcode2__WEBPACK_IMPORTED_MODULE_7__["NgxQRCodeModule"]
            ],
            declarations: [_show_qrcode_page__WEBPACK_IMPORTED_MODULE_6__["ShowQrcodePage"]]
        })
    ], ShowQrcodePageModule);
    return ShowQrcodePageModule;
}());



/***/ }),

/***/ "./src/app/pages/show-qrcode/show-qrcode.page.html":
/*!*********************************************************!*\
  !*** ./src/app/pages/show-qrcode/show-qrcode.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title>QR Code Gerado</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-card *ngIf=\"encodeData\">\n      <ngx-qrcode [(qrc-value)]=\"encodeData\"></ngx-qrcode>\n      <ion-card-content>\n          <!--<p>{{ encodeData }}</p>-->\n      </ion-card-content>\n  </ion-card>\n\n  <ion-button color=\"primary\" routerLink=\"/menu/produto\">\n    Voltar\n  </ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/show-qrcode/show-qrcode.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/show-qrcode/show-qrcode.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3Nob3ctcXJjb2RlL3Nob3ctcXJjb2RlLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/show-qrcode/show-qrcode.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/show-qrcode/show-qrcode.page.ts ***!
  \*******************************************************/
/*! exports provided: ShowQrcodePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShowQrcodePage", function() { return ShowQrcodePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var ShowQrcodePage = /** @class */ (function () {
    function ShowQrcodePage(barcodeScanner, activatedRoute, router, platform) {
        this.barcodeScanner = barcodeScanner;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.platform = platform;
    }
    ShowQrcodePage.prototype.ngOnInit = function () {
    };
    ShowQrcodePage.prototype.ionViewWillEnter = function () {
        this.encodeData = this.activatedRoute.snapshot
            .paramMap.get('id');
    };
    ShowQrcodePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-show-qrcode',
            template: __webpack_require__(/*! ./show-qrcode.page.html */ "./src/app/pages/show-qrcode/show-qrcode.page.html"),
            styles: [__webpack_require__(/*! ./show-qrcode.page.scss */ "./src/app/pages/show-qrcode/show-qrcode.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__["BarcodeScanner"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]])
    ], ShowQrcodePage);
    return ShowQrcodePage;
}());



/***/ })

}]);
//# sourceMappingURL=pages-show-qrcode-show-qrcode-module.js.map