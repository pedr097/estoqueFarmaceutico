(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["novo-produto-novo-produto-module"],{

/***/ "./src/app/pages/novo-produto/novo-produto.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/novo-produto/novo-produto.module.ts ***!
  \***********************************************************/
/*! exports provided: NovoProdutoPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NovoProdutoPageModule", function() { return NovoProdutoPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _novo_produto_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./novo-produto.page */ "./src/app/pages/novo-produto/novo-produto.page.ts");







var routes = [
    {
        path: '',
        component: _novo_produto_page__WEBPACK_IMPORTED_MODULE_6__["NovoProdutoPage"]
    }
];
var NovoProdutoPageModule = /** @class */ (function () {
    function NovoProdutoPageModule() {
    }
    NovoProdutoPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_novo_produto_page__WEBPACK_IMPORTED_MODULE_6__["NovoProdutoPage"]]
        })
    ], NovoProdutoPageModule);
    return NovoProdutoPageModule;
}());



/***/ }),

/***/ "./src/app/pages/novo-produto/novo-produto.page.html":
/*!***********************************************************!*\
  !*** ./src/app/pages/novo-produto/novo-produto.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Novo Produto</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n\r\n    <ion-item>\r\n      <ion-label>Nome:</ion-label>\r\n      <ion-input expand=\"block\" [(ngModel)]=\"produto.nome\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label>Descrição:</ion-label>\r\n      <ion-input expand=\"block\" [(ngModel)]=\"produto.descricao\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label>Data Vencimento</ion-label>\r\n      <ion-datetime displayFormat=\"DD/MM/YYYY\" [(ngModel)]=\"produto.data\"></ion-datetime>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label>Materias Primas</ion-label>\r\n      <ion-select multiple=\"true\" [(ngModel)]=\"produto.materiasprimas\">\r\n        <ion-select-option *ngFor=\"let item of (materiaprimaList | async) \" [value]=\"item\" selected>{{item.nome}}\r\n        </ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n\r\n  </ion-list>\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n  <ion-row no-padding text-center>\r\n    <ion-col size=\"6\">\r\n      <ion-toolbar color=\"success\"\r\n        *ngIf=\"produto.descricao && produto.nome && produto.data && produto.materiasprimas.length > 0\">\r\n        <ion-button expand=\"full\" fill=\"clear\" color=\"light\" (click)=\"salvar();\">\r\n          <ion-icon name=\"save\" slot=\"start\"></ion-icon>\r\n          Adicionar\r\n        </ion-button>\r\n      </ion-toolbar>\r\n    </ion-col>\r\n    <ion-col size=\"6\">\r\n      <ion-toolbar>\r\n        <ion-button expand=\"full\" fill=\"clear\" color=\"danger\" routerLink=\"/menu/produto\" routerDirection=\"root\"\r\n          routerLinkActive=\"active\">\r\n          <ion-icon name=\"trash\" slot=\"start\" routerLink=\"/menu/produto\" routerDirection=\"root\"\r\n            routerLinkActive=\"active\"></ion-icon>\r\n          Cancelar\r\n        </ion-button>\r\n      </ion-toolbar>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/pages/novo-produto/novo-produto.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/novo-produto/novo-produto.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25vdm8tcHJvZHV0by9ub3ZvLXByb2R1dG8ucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/novo-produto/novo-produto.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/novo-produto/novo-produto.page.ts ***!
  \*********************************************************/
/*! exports provided: NovoProdutoPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NovoProdutoPage", function() { return NovoProdutoPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_produto_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/produto.service */ "./src/app/services/produto.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/materia-prima.service */ "./src/app/services/materia-prima.service.ts");






var NovoProdutoPage = /** @class */ (function () {
    function NovoProdutoPage(produtoService, materiaService, toastCtrl, router) {
        this.produtoService = produtoService;
        this.materiaService = materiaService;
        this.toastCtrl = toastCtrl;
        this.router = router;
        this.produto = {};
        this.produto.data;
        this.produto.materiasprimas = {};
        this.materiaprimaList = this.materiaService.getMateriasPrima();
    }
    NovoProdutoPage.prototype.ngOnInit = function () {
    };
    NovoProdutoPage.prototype.salvar = function () {
        var _this = this;
        this.produtoService.addProduto(this.produto).then(function (res) { _this.salvou(res.id); })
            .catch(function (err) { _this.showToast("Erro ao salvar dados"); });
    };
    NovoProdutoPage.prototype.salvou = function (id) {
        this.showToast("Salvo com sucesso.");
        this.router.navigate(['/show-qrcode', id]);
        //this.router.navigate(['/menu/produto']);
    };
    NovoProdutoPage.prototype.showToast = function (msg) {
        this.toastCtrl.create({
            message: msg,
            duration: 2000
        }).then(function (toast) { return toast.present(); });
    };
    NovoProdutoPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-novo-produto',
            template: __webpack_require__(/*! ./novo-produto.page.html */ "./src/app/pages/novo-produto/novo-produto.page.html"),
            styles: [__webpack_require__(/*! ./novo-produto.page.scss */ "./src/app/pages/novo-produto/novo-produto.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_produto_service__WEBPACK_IMPORTED_MODULE_2__["ProdutoService"],
            src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_5__["MateriaPrimaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], NovoProdutoPage);
    return NovoProdutoPage;
}());



/***/ })

}]);
//# sourceMappingURL=novo-produto-novo-produto-module.js.map