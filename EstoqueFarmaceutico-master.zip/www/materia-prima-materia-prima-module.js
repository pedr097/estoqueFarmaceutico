(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["materia-prima-materia-prima-module"],{

/***/ "./src/app/pages/materia-prima/materia-prima.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/materia-prima/materia-prima.module.ts ***!
  \*************************************************************/
/*! exports provided: MateriaPrimaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MateriaPrimaPageModule", function() { return MateriaPrimaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _materia_prima_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./materia-prima.page */ "./src/app/pages/materia-prima/materia-prima.page.ts");







var routes = [
    {
        path: '',
        component: _materia_prima_page__WEBPACK_IMPORTED_MODULE_6__["MateriaPrimaPage"]
    }
];
var MateriaPrimaPageModule = /** @class */ (function () {
    function MateriaPrimaPageModule() {
    }
    MateriaPrimaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_materia_prima_page__WEBPACK_IMPORTED_MODULE_6__["MateriaPrimaPage"]]
        })
    ], MateriaPrimaPageModule);
    return MateriaPrimaPageModule;
}());



/***/ }),

/***/ "./src/app/pages/materia-prima/materia-prima.page.html":
/*!*************************************************************!*\
  !*** ./src/app/pages/materia-prima/materia-prima.page.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Materias Prima</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n \r\n<ion-content padding>\r\n  <ion-card *ngFor=\"let item of (materiaprimaList | async) \">\r\n      <ion-item>\r\n          <ion-label> {{item.nome}}</ion-label> \r\n          <ion-button slot=\"end\" (click)=\"deleteMateriaPrima(item.id)\"><ion-icon ios=\"ios-trash\" md=\"md-trash\"></ion-icon></ion-button>\r\n        </ion-item>\r\n\r\n        <ion-item>    \r\n          <ion-card-content>\r\n              {{item.descricao}}\r\n          </ion-card-content>\r\n        </ion-item>\r\n  </ion-card>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n   <!-- fab placed to the (vertical) center and end -->\r\n   <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\" routerLink=\"/menu/nova-materia-prima\" routerDirection=\"root\" routerLinkActive=\"active\">\r\n      <ion-fab-button>\r\n        <ion-icon name=\"add\" routerLink=\"/menu/nova-materia-prima\" routerDirection=\"root\" routerLinkActive=\"active\"></ion-icon>\r\n      </ion-fab-button>\r\n  </ion-fab>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/pages/materia-prima/materia-prima.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/materia-prima/materia-prima.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21hdGVyaWEtcHJpbWEvbWF0ZXJpYS1wcmltYS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/materia-prima/materia-prima.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/materia-prima/materia-prima.page.ts ***!
  \***********************************************************/
/*! exports provided: MateriaPrimaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MateriaPrimaPage", function() { return MateriaPrimaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/materia-prima.service */ "./src/app/services/materia-prima.service.ts");



var MateriaPrimaPage = /** @class */ (function () {
    function MateriaPrimaPage(materiaService) {
        this.materiaService = materiaService;
        this.materiaprimaList = this.materiaService.getMateriasPrima();
    }
    MateriaPrimaPage.prototype.ngOnInit = function () {
    };
    MateriaPrimaPage.prototype.deleteMateriaPrima = function (id) {
        this.materiaService.deleteMateriaPrima(id);
    };
    MateriaPrimaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-materia-prima',
            template: __webpack_require__(/*! ./materia-prima.page.html */ "./src/app/pages/materia-prima/materia-prima.page.html"),
            styles: [__webpack_require__(/*! ./materia-prima.page.scss */ "./src/app/pages/materia-prima/materia-prima.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_2__["MateriaPrimaService"]])
    ], MateriaPrimaPage);
    return MateriaPrimaPage;
}());



/***/ })

}]);
//# sourceMappingURL=materia-prima-materia-prima-module.js.map