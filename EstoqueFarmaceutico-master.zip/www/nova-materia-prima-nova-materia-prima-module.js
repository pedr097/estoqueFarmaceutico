(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["nova-materia-prima-nova-materia-prima-module"],{

/***/ "./src/app/pages/nova-materia-prima/nova-materia-prima.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/nova-materia-prima/nova-materia-prima.module.ts ***!
  \***********************************************************************/
/*! exports provided: NovaMateriaPrimaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NovaMateriaPrimaPageModule", function() { return NovaMateriaPrimaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _nova_materia_prima_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./nova-materia-prima.page */ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.ts");







var routes = [
    {
        path: '',
        component: _nova_materia_prima_page__WEBPACK_IMPORTED_MODULE_6__["NovaMateriaPrimaPage"]
    }
];
var NovaMateriaPrimaPageModule = /** @class */ (function () {
    function NovaMateriaPrimaPageModule() {
    }
    NovaMateriaPrimaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_nova_materia_prima_page__WEBPACK_IMPORTED_MODULE_6__["NovaMateriaPrimaPage"]]
        })
    ], NovaMateriaPrimaPageModule);
    return NovaMateriaPrimaPageModule;
}());



/***/ }),

/***/ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.html":
/*!***********************************************************************!*\
  !*** ./src/app/pages/nova-materia-prima/nova-materia-prima.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\r\n    <ion-toolbar color=\"primary\">\r\n        <ion-buttons slot=\"start\">\r\n            <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Nova Materia Prima</ion-title>\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-list>\r\n\r\n        <ion-item>\r\n            <ion-label>Nome:</ion-label>\r\n            <ion-input expand=\"block\" [(ngModel)]=\"materiaPrima.nome\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n            <ion-label>Descrição:</ion-label>\r\n            <ion-input expand=\"block\" [(ngModel)]=\"materiaPrima.descricao\"></ion-input>\r\n        </ion-item>\r\n\r\n    </ion-list>\r\n</ion-content>\r\n\r\n\r\n<ion-footer>\r\n    <ion-row no-padding text-center>\r\n        <ion-col size=\"6\">\r\n            <ion-toolbar color=\"success\" *ngIf=\"materiaPrima.descricao && materiaPrima.nome\">\r\n                <ion-button expand=\"full\" fill=\"clear\" color=\"light\" (click)=\"salvar();\">\r\n                    <ion-icon name=\"save\" slot=\"start\"></ion-icon>\r\n                    Adicionar\r\n                </ion-button>\r\n            </ion-toolbar>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n            <ion-toolbar>\r\n                <ion-button expand=\"full\" fill=\"clear\" color=\"danger\" routerLink=\"/menu/materia-prima\"\r\n                    routerDirection=\"root\" routerLinkActive=\"active\">\r\n                    <ion-icon name=\"trash\" slot=\"start\" routerLink=\"/menu/materia-prima\" routerDirection=\"root\"\r\n                        routerLinkActive=\"active\"></ion-icon>\r\n                    Cancelar\r\n                </ion-button>\r\n            </ion-toolbar>\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-footer>"

/***/ }),

/***/ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/pages/nova-materia-prima/nova-materia-prima.page.scss ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL25vdmEtbWF0ZXJpYS1wcmltYS9ub3ZhLW1hdGVyaWEtcHJpbWEucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/nova-materia-prima/nova-materia-prima.page.ts ***!
  \*********************************************************************/
/*! exports provided: NovaMateriaPrimaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NovaMateriaPrimaPage", function() { return NovaMateriaPrimaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/materia-prima.service */ "./src/app/services/materia-prima.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var NovaMateriaPrimaPage = /** @class */ (function () {
    function NovaMateriaPrimaPage(materiaService, toastCtrl, router) {
        this.materiaService = materiaService;
        this.toastCtrl = toastCtrl;
        this.router = router;
        this.materiaPrima = {};
    }
    NovaMateriaPrimaPage.prototype.ngOnInit = function () {
    };
    NovaMateriaPrimaPage.prototype.salvar = function () {
        var _this = this;
        this.materiaService.addMateriaPrima(this.materiaPrima).then(function (res) { _this.salvou(); })
            .catch(function (err) { _this.showToast("Erro ao salvar dados"); });
    };
    NovaMateriaPrimaPage.prototype.salvou = function () {
        this.showToast("Salvo com sucesso.");
        this.router.navigate(['/menu/materia-prima']);
    };
    NovaMateriaPrimaPage.prototype.showToast = function (msg) {
        this.toastCtrl.create({
            message: msg,
            duration: 2000
        }).then(function (toast) { return toast.present(); });
    };
    NovaMateriaPrimaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-nova-materia-prima',
            template: __webpack_require__(/*! ./nova-materia-prima.page.html */ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.html"),
            styles: [__webpack_require__(/*! ./nova-materia-prima.page.scss */ "./src/app/pages/nova-materia-prima/nova-materia-prima.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_services_materia_prima_service__WEBPACK_IMPORTED_MODULE_2__["MateriaPrimaService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], NovaMateriaPrimaPage);
    return NovaMateriaPrimaPage;
}());



/***/ })

}]);
//# sourceMappingURL=nova-materia-prima-nova-materia-prima-module.js.map