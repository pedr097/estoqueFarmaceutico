(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["leitura-leitura-module"],{

/***/ "./src/app/pages/leitura/leitura.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/leitura/leitura.module.ts ***!
  \*************************************************/
/*! exports provided: LeituraPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeituraPageModule", function() { return LeituraPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _leitura_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./leitura.page */ "./src/app/pages/leitura/leitura.page.ts");







var routes = [
    {
        path: '',
        component: _leitura_page__WEBPACK_IMPORTED_MODULE_6__["LeituraPage"]
    }
];
var LeituraPageModule = /** @class */ (function () {
    function LeituraPageModule() {
    }
    LeituraPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_leitura_page__WEBPACK_IMPORTED_MODULE_6__["LeituraPage"]]
        })
    ], LeituraPageModule);
    return LeituraPageModule;
}());



/***/ }),

/***/ "./src/app/pages/leitura/leitura.page.html":
/*!*************************************************!*\
  !*** ./src/app/pages/leitura/leitura.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Leitura QRCode</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<ion-list *ngIf=\"produto\">\n  <ion-card>\n    <ion-item>\n      <ion-label> {{produto.nome}}</ion-label>\n    </ion-item>\n\n    <ion-item>\n      <ion-card-content style=\"font-size: 10px\">\n        <p style=\"font-size: 12px\">{{produto.descricao}}</p>\n        <p style=\"font-size: 10px\">Vence na data de {{produto.data | date: 'dd/MM/yyyy'}}</p>\n      </ion-card-content>\n    </ion-item>\n\n    <ion-item *ngFor=\"let materiaprima of (produto.materiasprimas)\">\n      <ion-icon name=\"flask\" slot=\"start\" style=\"font-size: 14px\"></ion-icon>\n      <ion-label style=\"font-size: 10px\">{{materiaprima.nome}}</ion-label>\n    </ion-item>\n\n  </ion-card>\n</ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/pages/leitura/leitura.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/leitura/leitura.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2xlaXR1cmEvbGVpdHVyYS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/leitura/leitura.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/leitura/leitura.page.ts ***!
  \***********************************************/
/*! exports provided: LeituraPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeituraPage", function() { return LeituraPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/barcode-scanner/ngx */ "./node_modules/@ionic-native/barcode-scanner/ngx/index.js");
/* harmony import */ var src_app_services_produto_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/produto.service */ "./src/app/services/produto.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");






var LeituraPage = /** @class */ (function () {
    function LeituraPage(barcodeScanner, produtoService, router, platform) {
        this.barcodeScanner = barcodeScanner;
        this.produtoService = produtoService;
        this.router = router;
        this.platform = platform;
        this.barcodeScannerOptions = {
            showTorchButton: true,
            showFlipCameraButton: true
        };
        this.scanCode();
    }
    LeituraPage.prototype.ngOnInit = function () {
    };
    LeituraPage.prototype.scanCode = function () {
        var _this = this;
        this.barcodeScanner
            .scan()
            .then(function (barcodeData) {
            //alert("Barcode data " + JSON.stringify(barcodeData));
            _this.scannedData = barcodeData;
            _this.buscaProduto(barcodeData["text"]);
        })
            .catch(function (err) {
            console.log("Erro: ", err);
        });
    };
    LeituraPage.prototype.buscaProduto = function (id) {
        var _this = this;
        this.produtoService.getProdutoByID(id).subscribe(function (res) {
            _this.produto = {};
            _this.produto.data = res.data,
                _this.produto.descricao = res.descricao,
                _this.produto.nome = res.nome,
                _this.produto.materiasprimas = res.materiasprimas;
        });
    };
    LeituraPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-leitura',
            template: __webpack_require__(/*! ./leitura.page.html */ "./src/app/pages/leitura/leitura.page.html"),
            styles: [__webpack_require__(/*! ./leitura.page.scss */ "./src/app/pages/leitura/leitura.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_barcode_scanner_ngx__WEBPACK_IMPORTED_MODULE_2__["BarcodeScanner"],
            src_app_services_produto_service__WEBPACK_IMPORTED_MODULE_3__["ProdutoService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"]])
    ], LeituraPage);
    return LeituraPage;
}());



/***/ })

}]);
//# sourceMappingURL=leitura-leitura-module.js.map