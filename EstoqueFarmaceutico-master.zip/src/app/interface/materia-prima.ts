export interface MateriaPrima {
    id: string;
    nome: string;
    descricao: string;
 }